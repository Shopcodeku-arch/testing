package id.tokoardan.dungeon.dungeon;

import id.tokoardan.dungeon.DungeonPlugin;
import id.tokoardan.dungeon.mobs.MobType;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.type.Slab;
import org.bukkit.block.data.type.Stairs;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;

public class DungeonGenerator {

    private final DungeonPlugin plugin;
    private final Random rng = new Random();

    // Blok material per zona
    private static final Material[] WALL_MATS    = {
        Material.DEEPSLATE_BRICKS, Material.CRACKED_DEEPSLATE_BRICKS,
        Material.DEEPSLATE_TILES,  Material.CHISELED_DEEPSLATE
    };
    private static final Material[] FLOOR_MATS   = {
        Material.DEEPSLATE_BRICK_SLAB, Material.COBBLED_DEEPSLATE,
        Material.SMOOTH_STONE
    };
    private static final Material[] CEILING_MATS = {
        Material.DEEPSLATE_BRICKS, Material.CHISELED_DEEPSLATE
    };

    public DungeonGenerator(DungeonPlugin plugin) { this.plugin = plugin; }

    // ── Entry point: generate dungeon ────────────────────────────
    public void generate(Location start, Player initiator) {
        int totalRooms = plugin.getConfig().getInt("dungeon.rooms", 12);
        int baseY      = plugin.getConfig().getInt("dungeon.depth", -30);

        Location base  = new Location(start.getWorld(), start.getBlockX(), baseY, start.getBlockZ());

        if (initiator != null)
            initiator.sendMessage(ChatColor.YELLOW + "⚙ Generating dungeon... silakan tunggu.");

        List<DungeonRoom> rooms = planLayout(base, totalRooms);

        // Generate async per chunk agar server tidak lag
        new BukkitRunnable() {
            int index = 0;

            @Override
            public void run() {
                if (index >= rooms.size()) {
                    // Selesai — spawn mob
                    spawnAllMobs(rooms);
                    if (initiator != null) {
                        initiator.sendMessage(
                            ChatColor.GREEN + "✔ Dungeon berhasil dibuat! " +
                            ChatColor.YELLOW + rooms.size() + " ruangan."
                        );
                        initiator.sendMessage(
                            ChatColor.GOLD + "Lokasi: " +
                            ChatColor.WHITE + base.getBlockX() + ", " + base.getBlockY() + ", " + base.getBlockZ()
                        );
                    }
                    cancel();
                    return;
                }
                buildRoom(rooms.get(index));
                // Lorong ke ruangan berikutnya
                if (index + 1 < rooms.size()) {
                    buildCorridor(rooms.get(index), rooms.get(index + 1));
                }
                index++;
            }
        }.runTaskTimer(plugin, 2L, 4L);
    }

    // ── Rencanakan layout ruangan ─────────────────────────────────
    private List<DungeonRoom> planLayout(Location base, int totalRooms) {
        List<DungeonRoom> rooms = new ArrayList<>();
        Location cursor = base.clone();

        // Arah layout: kita zigzag supaya lebih menarik
        int[][] directions = {{1,0},{0,1},{-1,0},{0,-1}};
        int dirIdx = 0;

        for (int i = 0; i < totalRooms; i++) {
            DungeonRoom.RoomType rType;
            int w, d;

            if (i == 0) {
                rType = DungeonRoom.RoomType.ENTRANCE;
                w = 9; d = 9;
            } else if (i == totalRooms - 1) {
                rType = DungeonRoom.RoomType.BOSS;
                w = 25; d = 25;
            } else if (i % 5 == 0) {
                rType = DungeonRoom.RoomType.TREASURE;
                w = 11; d = 11;
            } else if (i % 4 == 0) {
                rType = DungeonRoom.RoomType.TRAP;
                w = 9; d = 9;
            } else if (i % 3 == 0) {
                rType = DungeonRoom.RoomType.COMBAT;
                w = 13; d = 13;
            } else {
                rType = DungeonRoom.RoomType.CORRIDOR;
                w = 7; d = 12;
            }

            int h = (rType == DungeonRoom.RoomType.BOSS) ? 8 : 5;
            List<MobType> mobs = chooseMobs(rType, i, totalRooms);

            rooms.add(new DungeonRoom(rType, cursor.clone(), w, h, d, mobs));

            // Geser cursor untuk ruangan berikutnya
            int[] dir = directions[dirIdx % 4];
            cursor.add(dir[0] * (w + 3), 0, dir[1] * (d + 3));

            // Ganti arah tiap 3 ruangan
            if ((i + 1) % 3 == 0) dirIdx++;
        }

        return rooms;
    }

    // ── Pilih mob berdasarkan jenis & posisi ruangan ──────────────
    private List<MobType> chooseMobs(DungeonRoom.RoomType rType, int roomIdx, int total) {
        List<MobType> list = new ArrayList<>();
        double progress = (double) roomIdx / total; // 0.0 - 1.0

        switch (rType) {
            case ENTRANCE -> {
                list.add(MobType.GOBLIN);
                list.add(MobType.GOBLIN);
            }
            case CORRIDOR -> {
                if (progress < 0.3) {
                    list.add(pickRandom(MobType.GOBLIN, MobType.GOBLIN_ARCHER, MobType.CAVE_BAT));
                } else if (progress < 0.6) {
                    list.add(pickRandom(MobType.DUNGEON_GUARD, MobType.SKELETON_WARRIOR));
                    list.add(pickRandom(MobType.GOBLIN, MobType.CAVE_BAT));
                } else {
                    list.add(pickRandom(MobType.SHADOW_KNIGHT, MobType.UNDEAD_CAPTAIN));
                    list.add(MobType.SKELETON_WARRIOR);
                }
            }
            case COMBAT -> {
                if (progress < 0.4) {
                    list.add(MobType.DUNGEON_GUARD); list.add(MobType.DUNGEON_GUARD);
                    list.add(MobType.DARK_MAGE);
                } else if (progress < 0.7) {
                    list.add(MobType.TROLL); list.add(MobType.SKELETON_WARRIOR);
                    list.add(MobType.SHADOW_KNIGHT);
                } else {
                    list.add(MobType.DEMON); list.add(MobType.NIGHTMARE);
                    list.add(MobType.LICH);
                }
            }
            case TRAP -> {
                list.add(pickRandom(MobType.GOBLIN_ARCHER, MobType.SKELETON_WARRIOR));
                list.add(MobType.CAVE_BAT);
            }
            case TREASURE -> {
                // Penjaga harta
                if (progress < 0.5) {
                    list.add(MobType.DUNGEON_GUARD); list.add(MobType.DUNGEON_GUARD);
                } else {
                    list.add(MobType.SHADOW_KNIGHT); list.add(MobType.LICH);
                }
            }
            case BOSS -> list.add(MobType.DEMON_KING);
        }

        return list;
    }

    @SafeVarargs
    private <T> T pickRandom(T... items) {
        return items[rng.nextInt(items.length)];
    }

    // ── Build satu ruangan ────────────────────────────────────────
    private void buildRoom(DungeonRoom room) {
        Location o = room.getOrigin();
        int w = room.getWidth(), h = room.getHeight(), d = room.getDepth();
        World world = o.getWorld();
        if (world == null) return;

        for (int x = 0; x <= w; x++) {
            for (int y = 0; y <= h; y++) {
                for (int z = 0; z <= d; z++) {
                    Block block = world.getBlockAt(
                        o.getBlockX() + x,
                        o.getBlockY() + y,
                        o.getBlockZ() + z
                    );

                    // Lantai
                    if (y == 0) {
                        block.setType(randomFrom(FLOOR_MATS));
                    }
                    // Atap
                    else if (y == h) {
                        block.setType(randomFrom(CEILING_MATS));
                        // Tambah sedikit stalaktit
                        if (rng.nextInt(12) == 0) {
                            Block stal = world.getBlockAt(block.getX(), block.getY() - 1, block.getZ());
                            stal.setType(Material.POINTED_DRIPSTONE);
                        }
                    }
                    // Dinding
                    else if (x == 0 || x == w || z == 0 || z == d) {
                        block.setType(randomFrom(WALL_MATS));
                        // Crack random
                        if (rng.nextInt(8) == 0) block.setType(Material.CRACKED_DEEPSLATE_BRICKS);
                        // Mossy
                        if (rng.nextInt(15) == 0) block.setType(Material.MOSSY_COBBLESTONE);
                        // Torch di dinding
                        if (y == 2 && (x == 0 || x == w || z == 0 || z == d) && rng.nextInt(10) == 0) {
                            placeTorchOnWall(block);
                        }
                    }
                    // Interior — kosongkan
                    else {
                        block.setType(Material.AIR);
                    }
                }
            }
        }

        // Dekorasi berdasarkan tipe
        decorateRoom(room);
    }

    private void placeTorchOnWall(Block wallBlock) {
        // Tempatkan soul torch/lantern di sekitar dinding
        BlockFace[] faces = {BlockFace.NORTH, BlockFace.SOUTH, BlockFace.EAST, BlockFace.WEST};
        for (BlockFace face : faces) {
            Block adj = wallBlock.getRelative(face);
            if (adj.getType() == Material.AIR) {
                Material torch = rng.nextBoolean() ? Material.SOUL_TORCH : Material.TORCH;
                adj.setType(torch);
                break;
            }
        }
    }

    // ── Dekorasi per jenis ruangan ────────────────────────────────
    private void decorateRoom(DungeonRoom room) {
        switch (room.getType()) {
            case ENTRANCE    -> decorateEntrance(room);
            case TREASURE    -> decorateTreasure(room);
            case TRAP        -> decorateTrap(room);
            case BOSS        -> decorateBoss(room);
            case COMBAT      -> decorateCombat(room);
            default          -> decorateCorridor(room);
        }
    }

    private void decorateEntrance(DungeonRoom room) {
        Location c = room.getCenter();
        World w = c.getWorld();
        if (w == null) return;

        // Sign di pintu masuk
        Block signBase = w.getBlockAt(c.getBlockX(), c.getBlockY() + 2, c.getBlockZ());
        signBase.setType(Material.OAK_SIGN);

        // Pilar di sudut
        Location o = room.getOrigin();
        placeColumn(w, o.getBlockX() + 1, o.getBlockY(), o.getBlockZ() + 1, room.getHeight() - 1);
        placeColumn(w, o.getBlockX() + room.getWidth() - 1, o.getBlockY(), o.getBlockZ() + 1, room.getHeight() - 1);
        placeColumn(w, o.getBlockX() + 1, o.getBlockY(), o.getBlockZ() + room.getDepth() - 1, room.getHeight() - 1);
        placeColumn(w, o.getBlockX() + room.getWidth() - 1, o.getBlockY(), o.getBlockZ() + room.getDepth() - 1, room.getHeight() - 1);

        // Soul fire di tengah
        w.getBlockAt(c.getBlockX(), c.getBlockY(), c.getBlockZ()).setType(Material.SOUL_FIRE);
    }

    private void decorateTreasure(DungeonRoom room) {
        Location o = room.getOrigin();
        World w = o.getWorld();
        if (w == null) return;
        int cx = o.getBlockX() + room.getWidth() / 2;
        int cz = o.getBlockZ() + room.getDepth() / 2;

        // Chest di tengah
        Block chest = w.getBlockAt(cx, o.getBlockY() + 1, cz);
        chest.setType(Material.CHEST);
        fillChest(chest, room);

        // Surrounded by gold blocks
        w.getBlockAt(cx - 1, o.getBlockY(), cz).setType(Material.GOLD_BLOCK);
        w.getBlockAt(cx + 1, o.getBlockY(), cz).setType(Material.GOLD_BLOCK);
        w.getBlockAt(cx, o.getBlockY(), cz - 1).setType(Material.GOLD_BLOCK);
        w.getBlockAt(cx, o.getBlockY(), cz + 1).setType(Material.GOLD_BLOCK);

        // Candlesticks
        for (int dx = -3; dx <= 3; dx += 3) {
            Block candle = w.getBlockAt(cx + dx, o.getBlockY() + 1, cz);
            if (candle.getType() == Material.AIR) candle.setType(Material.CANDLE);
        }
    }

    private void fillChest(Block chestBlock, DungeonRoom room) {
        // Isi chest sederhana
        if (!(chestBlock.getState() instanceof org.bukkit.block.Chest chest)) return;
        org.bukkit.inventory.Inventory inv = chest.getInventory();

        // Item acak
        Material[] loot = {
            Material.GOLD_INGOT, Material.IRON_INGOT, Material.DIAMOND,
            Material.EMERALD, Material.ENCHANTED_GOLDEN_APPLE,
            Material.EXPERIENCE_BOTTLE, Material.ARROW, Material.BREAD
        };
        for (int i = 0; i < 3 + rng.nextInt(5); i++) {
            int slot = rng.nextInt(27);
            Material mat = loot[rng.nextInt(loot.length)];
            inv.setItem(slot, new org.bukkit.inventory.ItemStack(mat, 1 + rng.nextInt(8)));
        }
    }

    private void decorateTrap(DungeonRoom room) {
        Location o = room.getOrigin();
        World w = o.getWorld();
        if (w == null) return;

        // Pressure plate + TNT jebakan
        int cx = o.getBlockX() + room.getWidth() / 2;
        int cz = o.getBlockZ() + room.getDepth() / 2;

        // TNT tersembunyi di bawah lantai
        w.getBlockAt(cx, o.getBlockY() - 1, cz).setType(Material.TNT);
        w.getBlockAt(cx, o.getBlockY() - 1, cz + 2).setType(Material.TNT);
        // Pressure plate di atas
        w.getBlockAt(cx, o.getBlockY() + 1, cz).setType(Material.STONE_PRESSURE_PLATE);

        // Stalaktit di atap
        for (int x = 2; x < room.getWidth() - 2; x += 2) {
            for (int z = 2; z < room.getDepth() - 2; z += 2) {
                Block stalBlock = w.getBlockAt(o.getBlockX() + x,
                    o.getBlockY() + room.getHeight() - 1, o.getBlockZ() + z);
                if (rng.nextBoolean()) stalBlock.setType(Material.POINTED_DRIPSTONE);
            }
        }

        // Lava pocket di sudut
        w.getBlockAt(o.getBlockX() + 1, o.getBlockY() + 1, o.getBlockZ() + 1).setType(Material.LAVA);
    }

    private void decorateBoss(DungeonRoom room) {
        Location o = room.getOrigin();
        World w = o.getWorld();
        if (w == null) return;
        int cx = o.getBlockX() + room.getWidth() / 2;
        int cz = o.getBlockZ() + room.getDepth() / 2;

        // Altar di tengah dari Netherite/Obsidian
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                w.getBlockAt(cx + dx, o.getBlockY(), cz + dz).setType(Material.OBSIDIAN);
            }
        }
        // Pilar raksasa
        for (int corner = 0; corner < 4; corner++) {
            int px = cx + (corner < 2 ? -8 : 8);
            int pz = cz + (corner % 2 == 0 ? -8 : 8);
            placeColumn(w, px, o.getBlockY(), pz, room.getHeight() - 1);
            // Api di atas pilar
            w.getBlockAt(px, o.getBlockY() + room.getHeight(), pz).setType(Material.SOUL_FIRE);
        }

        // Nether brick di dinding boss room
        for (int x = 0; x <= room.getWidth(); x++) {
            for (int y = 1; y < room.getHeight(); y++) {
                Block b = w.getBlockAt(o.getBlockX() + x, o.getBlockY() + y, o.getBlockZ());
                if (b.getType() != Material.AIR) b.setType(Material.NETHER_BRICKS);
                b = w.getBlockAt(o.getBlockX() + x, o.getBlockY() + y,
                    o.getBlockZ() + room.getDepth());
                if (b.getType() != Material.AIR) b.setType(Material.NETHER_BRICKS);
            }
        }

        // Soul sand di lantai boss area
        for (int dx = -4; dx <= 4; dx++) {
            for (int dz = -4; dz <= 4; dz++) {
                w.getBlockAt(cx + dx, o.getBlockY(), cz + dz).setType(Material.SOUL_SAND);
            }
        }

        // Lava moat
        for (int x = 2; x < room.getWidth() - 2; x++) {
            w.getBlockAt(o.getBlockX() + x, o.getBlockY(), o.getBlockZ() + 2).setType(Material.LAVA);
            w.getBlockAt(o.getBlockX() + x, o.getBlockY(), o.getBlockZ() + room.getDepth() - 2).setType(Material.LAVA);
        }
    }

    private void decorateCombat(DungeonRoom room) {
        Location o = room.getOrigin();
        World w = o.getWorld();
        if (w == null) return;

        // Spawner mob
        int cx = o.getBlockX() + room.getWidth() / 2;
        int cz = o.getBlockZ() + room.getDepth() / 2;
        Block spawner = w.getBlockAt(cx, o.getBlockY() + 1, cz);
        spawner.setType(Material.SPAWNER);

        // Pilar kecil di sudut
        placeColumn(w, o.getBlockX() + 2, o.getBlockY(), o.getBlockZ() + 2, 2);
        placeColumn(w, o.getBlockX() + room.getWidth() - 2, o.getBlockY(), o.getBlockZ() + 2, 2);
    }

    private void decorateCorridor(DungeonRoom room) {
        Location o = room.getOrigin();
        World w = o.getWorld();
        if (w == null) return;

        // Torch acak di sepanjang lorong
        for (int z = 2; z < room.getDepth(); z += 4) {
            Block torch = w.getBlockAt(o.getBlockX() + 1, o.getBlockY() + 2, o.getBlockZ() + z);
            if (torch.getType() == Material.AIR) torch.setType(Material.WALL_TORCH);
        }

        // Cobweb sporadis
        for (int i = 0; i < 3; i++) {
            int rx = 1 + rng.nextInt(room.getWidth() - 2);
            int rz = 1 + rng.nextInt(room.getDepth() - 2);
            Block cb = w.getBlockAt(o.getBlockX() + rx, o.getBlockY() + room.getHeight() - 1, o.getBlockZ() + rz);
            if (cb.getType() == Material.AIR) cb.setType(Material.COBWEB);
        }
    }

    // ── Build lorong antar ruangan ────────────────────────────────
    private void buildCorridor(DungeonRoom from, DungeonRoom to) {
        Location a = from.getCenter();
        Location b = to.getCenter();
        World w = a.getWorld();
        if (w == null) return;

        int ax = a.getBlockX(), az = a.getBlockZ(), y = a.getBlockY();
        int bx = b.getBlockX(), bz = b.getBlockZ();

        // L-shaped corridor
        // Horizontal dulu
        int minX = Math.min(ax, bx), maxX = Math.max(ax, bx);
        for (int x = minX - 1; x <= maxX + 1; x++) {
            clearCorridor(w, x, y, az);
        }
        // Lalu vertical
        int minZ = Math.min(az, bz), maxZ = Math.max(az, bz);
        for (int z = minZ - 1; z <= maxZ + 1; z++) {
            clearCorridor(w, bx, y, z);
        }
    }

    private void clearCorridor(World world, int x, int y, int z) {
        // 3 blok lebar, 3 blok tinggi
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = 0; dy <= 3; dy++) {
                for (int dz = -1; dz <= 1; dz++) {
                    Block b = world.getBlockAt(x + dx, y + dy, z + dz);
                    if (dy == 0) {
                        b.setType(Material.COBBLED_DEEPSLATE); // lantai
                    } else {
                        b.setType(Material.AIR);
                    }
                }
            }
            // Dinding lorong
            world.getBlockAt(x + dx, y + 4, z).setType(Material.DEEPSLATE_BRICKS);
        }
    }

    // ── Spawn semua mob ───────────────────────────────────────────
    private void spawnAllMobs(List<DungeonRoom> rooms) {
        for (DungeonRoom room : rooms) {
            if (!plugin.getConfig().getBoolean("dungeon.mob-spawn-chance-check", true) ||
                rng.nextDouble() < plugin.getConfig().getDouble("dungeon.mob-spawn-chance", 0.85)) {

                for (MobType mobType : room.getMobs()) {
                    Location spawnLoc = randomInsideRoom(room);
                    plugin.getMobManager().spawnMob(spawnLoc, mobType);

                    // Particle saat spawn
                    if (plugin.getConfig().getBoolean("dungeon.particles", true)) {
                        spawnLoc.getWorld().spawnParticle(
                            Particle.SMOKE_LARGE, spawnLoc, 20, 0.5, 0.5, 0.5, 0.02
                        );
                    }
                }
            }
        }
    }

    private Location randomInsideRoom(DungeonRoom room) {
        Location o = room.getOrigin();
        int rx = 2 + rng.nextInt(Math.max(1, room.getWidth() - 4));
        int rz = 2 + rng.nextInt(Math.max(1, room.getDepth() - 4));
        return new Location(o.getWorld(), o.getBlockX() + rx, o.getBlockY() + 1, o.getBlockZ() + rz);
    }

    // ── Util ──────────────────────────────────────────────────────
    private void placeColumn(World w, int x, int baseY, int z, int height) {
        for (int y = 0; y <= height; y++) {
            Material mat = (y == 0 || y == height) ? Material.CHISELED_DEEPSLATE
                         : Material.DEEPSLATE_BRICK_WALL;
            w.getBlockAt(x, baseY + y, z).setType(mat);
        }
        // Lantern di atas
        w.getBlockAt(x, baseY + height + 1, z).setType(Material.SOUL_LANTERN);
    }

    private Material randomFrom(Material[] mats) {
        return mats[rng.nextInt(mats.length)];
    }
}
