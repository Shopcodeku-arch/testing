package id.tokoardan.dungeon.mobs;

import id.tokoardan.dungeon.DungeonPlugin;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.*;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

public class MobManager {

    private final DungeonPlugin plugin;
    private final Map<UUID, MobType>  customMobs    = new HashMap<>();
    private final Map<UUID, ArmorStand> healthBars  = new HashMap<>();
    private final Map<UUID, BossBar>    bossBars     = new HashMap<>();

    public static final NamespacedKey KEY_MOB_TYPE = new NamespacedKey("dungeon", "mob_type");
    public static final NamespacedKey KEY_DUNGEON   = new NamespacedKey("dungeon", "is_dungeon_mob");

    private BukkitTask healthBarTask;

    public MobManager(DungeonPlugin plugin) {
        this.plugin = plugin;
    }

    // ── Spawn mob ─────────────────────────────────────────────────
    public LivingEntity spawnMob(Location loc, MobType type) {
        World world = loc.getWorld();
        if (world == null) return null;

        LivingEntity entity = (LivingEntity) world.spawnEntity(loc, type.entityType);
        applyMobAttributes(entity, type);
        customMobs.put(entity.getUniqueId(), type);

        // Spawn health bar ArmorStand
        if (plugin.getConfig().getBoolean("healthbar.enabled", true)) {
            spawnHealthBar(entity, type);
        }

        // Boss: bossbar
        if (type.isBoss) {
            setupBossBar(entity, type);
        }

        // Tambahkan metadata
        entity.getPersistentDataContainer().set(KEY_MOB_TYPE, PersistentDataType.STRING, type.name());
        entity.getPersistentDataContainer().set(KEY_DUNGEON,   PersistentDataType.BYTE,  (byte) 1);

        return entity;
    }

    // ── Terapkan atribut mob ──────────────────────────────────────
    private void applyMobAttributes(LivingEntity e, MobType type) {
        e.setCustomNameVisible(false); // nama dihandle oleh armorstand

        // HP
        AttributeInstance maxHp = e.getAttribute(Attribute.GENERIC_MAX_HEALTH);
        if (maxHp != null) {
            maxHp.setBaseValue(type.maxHealth);
            e.setHealth(type.maxHealth);
        }

        // Attack
        AttributeInstance atk = e.getAttribute(Attribute.GENERIC_ATTACK_DAMAGE);
        if (atk != null) atk.setBaseValue(type.attackDamage);

        // Armor
        AttributeInstance armor = e.getAttribute(Attribute.GENERIC_ARMOR);
        if (armor != null) armor.setBaseValue(type.armorPoints);

        // Speed
        AttributeInstance speed = e.getAttribute(Attribute.GENERIC_MOVEMENT_SPEED);
        if (speed != null && type.speedBoost > 0) {
            speed.setBaseValue(speed.getBaseValue() + type.speedBoost);
        }

        // Follow range lebih jauh
        AttributeInstance follow = e.getAttribute(Attribute.GENERIC_FOLLOW_RANGE);
        if (follow != null) follow.setBaseValue(32.0);

        // Equipment berdasarkan tier
        applyEquipment(e, type);

        // Efek visual
        applyVisualEffects(e, type);
    }

    // ── Equipment per tier ────────────────────────────────────────
    private void applyEquipment(LivingEntity e, MobType type) {
        if (!(e instanceof Zombie) && !(e instanceof Skeleton) && !(e instanceof ZombieVillager)) return;
        EntityEquipment eq = e.getEquipment();
        if (eq == null) return;

        // Drop chance rendah agar tidak mudah
        eq.setItemInMainHandDropChance(0.05f);
        eq.setHelmetDropChance(0.02f);
        eq.setChestplateDropChance(0.02f);
        eq.setLeggingsDropChance(0.02f);
        eq.setBootsDropChance(0.02f);

        switch (type) {
            case SHADOW_KNIGHT -> {
                eq.setHelmet(new ItemStack(Material.IRON_HELMET));
                eq.setChestplate(new ItemStack(Material.IRON_CHESTPLATE));
                eq.setLeggings(new ItemStack(Material.IRON_LEGGINGS));
                eq.setBoots(new ItemStack(Material.IRON_BOOTS));
                eq.setItemInMainHand(new ItemStack(Material.IRON_SWORD));
            }
            case UNDEAD_CAPTAIN -> {
                eq.setHelmet(new ItemStack(Material.CHAINMAIL_HELMET));
                eq.setChestplate(new ItemStack(Material.CHAINMAIL_CHESTPLATE));
                eq.setItemInMainHand(new ItemStack(Material.IRON_AXE));
            }
            case LICH -> {
                eq.setHelmet(new ItemStack(Material.NETHERITE_HELMET));
                eq.setChestplate(new ItemStack(Material.NETHERITE_CHESTPLATE));
                eq.setItemInMainHand(new ItemStack(Material.NETHERITE_SWORD));
            }
            case DUNGEON_GUARD -> {
                eq.setHelmet(new ItemStack(Material.LEATHER_HELMET));
                eq.setChestplate(new ItemStack(Material.LEATHER_CHESTPLATE));
                eq.setItemInMainHand(new ItemStack(Material.STONE_SWORD));
            }
            default -> {}
        }
    }

    // ── Visual effects tiap mob ───────────────────────────────────
    private void applyVisualEffects(LivingEntity e, MobType type) {
        switch (type.tier) {
            case ELITE -> e.setGlowing(true);
            case BOSS  -> e.setGlowing(true);
            default    -> {}
        }
        // Phantom tetap invisible seperti biasa
        if (type == MobType.NIGHTMARE || type == MobType.CAVE_BAT) {
            e.setGlowing(true);
        }
    }

    // ── ArmorStand health bar ─────────────────────────────────────
    private void spawnHealthBar(LivingEntity mob, MobType type) {
        Location barLoc = mob.getLocation().add(0, getBarOffset(mob), 0);
        ArmorStand stand = (ArmorStand) mob.getWorld().spawnEntity(barLoc, EntityType.ARMOR_STAND);
        stand.setVisible(false);
        stand.setGravity(false);
        stand.setSmall(true);
        stand.setCustomNameVisible(true);
        stand.setMarker(true);
        stand.setInvulnerable(true);
        stand.setPersistent(false);

        updateHealthBarName(stand, type, mob.getHealth(), type.maxHealth);
        healthBars.put(mob.getUniqueId(), stand);
    }

    private double getBarOffset(LivingEntity mob) {
        return switch (mob.getType()) {
            case WITHER          -> 5.5;
            case HOGLIN          -> 2.8;
            case PHANTOM         -> 2.2;
            case BLAZE           -> 2.5;
            default              -> 2.4;
        };
    }

    /** Format nama ArmorStand: ❤ [██████░░░░] 60/100 ⚔ 8 */
    private void updateHealthBarName(ArmorStand stand, MobType type,
                                     double currentHp, double maxHp) {
        int barLen  = plugin.getConfig().getInt("healthbar.bar-length", 10);
        int filled  = (int) Math.round((currentHp / maxHp) * barLen);
        filled      = Math.max(0, Math.min(barLen, filled));

        ChatColor barColor = filled > barLen * 0.5 ? ChatColor.GREEN
                           : filled > barLen * 0.25 ? ChatColor.YELLOW
                           : ChatColor.RED;

        String bar = barColor + plugin.getConfig().getString("healthbar.bar-filled","█").repeat(filled)
                   + ChatColor.DARK_GRAY + plugin.getConfig().getString("healthbar.bar-empty","░").repeat(barLen - filled);

        String hpText  = barColor + (int) currentHp + ChatColor.DARK_GRAY + "/" + (int) maxHp;
        String atkText = ChatColor.RED + "⚔" + ChatColor.WHITE + (int) type.attackDamage;
        String tier    = getTierTag(type);

        String name = type.coloredName() + " " + tier + "\n"
                    + ChatColor.RED + "❤ " + bar + " " + hpText + "  " + atkText;

        stand.setCustomName(name);
    }

    private String getTierTag(MobType type) {
        return switch (type.tier) {
            case WEAK   -> ChatColor.GRAY    + "[Lemah]";
            case MEDIUM -> ChatColor.YELLOW  + "[Menengah]";
            case STRONG -> ChatColor.RED     + "[Kuat]";
            case ELITE  -> ChatColor.GOLD    + "★[Elite]★";
            case BOSS   -> ChatColor.DARK_RED + ChatColor.BOLD + "☠[BOSS]☠";
        };
    }

    // ── BossBar untuk Raja Iblis ──────────────────────────────────
    private void setupBossBar(LivingEntity entity, MobType type) {
        BossBar bar = Bukkit.createBossBar(
            ChatColor.DARK_RED + ChatColor.BOLD.toString() + "☠ " + type.displayName + " ☠",
            BarColor.RED, BarStyle.SEGMENTED_10
        );
        bossBars.put(entity.getUniqueId(), bar);

        // Broadcast ke semua player dalam radius
        int radius = plugin.getConfig().getInt("boss.bossbar-radius", 100);
        entity.getWorld().getPlayers().forEach(p -> {
            if (p.getLocation().distance(entity.getLocation()) <= radius) {
                bar.addPlayer(p);
            }
        });

        if (plugin.getConfig().getBoolean("boss.announce", true)) {
            Bukkit.broadcastMessage(
                ChatColor.DARK_RED + "☠ " + ChatColor.RED + ChatColor.BOLD + "RAJA IBLIS TELAH BANGKIT!" +
                ChatColor.DARK_RED + " ☠"
            );
            Bukkit.broadcastMessage(
                ChatColor.GOLD + "Bunuh dia sebelum menghancurkan segalanya!"
            );
        }
    }

    // ── Update health bar task ────────────────────────────────────
    public void startHealthBarTask() {
        int interval = plugin.getConfig().getInt("healthbar.update-interval", 4);
        healthBarTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            Iterator<Map.Entry<UUID, ArmorStand>> it = healthBars.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<UUID, ArmorStand> entry = it.next();
                UUID mobId = entry.getKey();
                ArmorStand stand = entry.getValue();

                Entity mobEnt = Bukkit.getEntity(mobId);
                if (mobEnt == null || !mobEnt.isValid() || mobEnt.isDead()) {
                    stand.remove();
                    it.remove();
                    // Hapus bossbar jika ada
                    BossBar bb = bossBars.remove(mobId);
                    if (bb != null) bb.removeAll();
                    customMobs.remove(mobId);
                    continue;
                }

                LivingEntity mob = (LivingEntity) mobEnt;
                MobType type = customMobs.get(mobId);
                if (type == null) continue;

                // Gerakkan stand mengikuti mob
                double offset = getBarOffset(mob);
                Location newLoc = mob.getLocation().add(0, offset, 0);
                stand.teleport(newLoc);

                // Update nama
                updateHealthBarName(stand, type, mob.getHealth(),
                    Objects.requireNonNull(mob.getAttribute(Attribute.GENERIC_MAX_HEALTH)).getValue());

                // Update bossbar
                BossBar bb = bossBars.get(mobId);
                if (bb != null) {
                    double maxHp = Objects.requireNonNull(mob.getAttribute(Attribute.GENERIC_MAX_HEALTH)).getValue();
                    bb.setProgress(Math.max(0, mob.getHealth() / maxHp));

                    // Tambah player yang masuk radius
                    int r = plugin.getConfig().getInt("boss.bossbar-radius", 100);
                    mob.getWorld().getPlayers().forEach(p -> {
                        if (p.getLocation().distance(mob.getLocation()) <= r && !bb.getPlayers().contains(p)) {
                            bb.addPlayer(p);
                        } else if (p.getLocation().distance(mob.getLocation()) > r) {
                            bb.removePlayer(p);
                        }
                    });
                }
            }
        }, 10L, interval);
    }

    // ── API publik ────────────────────────────────────────────────
    public boolean isDungeonMob(Entity e) {
        return e.getPersistentDataContainer().has(KEY_DUNGEON, PersistentDataType.BYTE);
    }

    public MobType getMobType(Entity e) {
        String raw = e.getPersistentDataContainer().get(KEY_MOB_TYPE, PersistentDataType.STRING);
        if (raw == null) return null;
        try { return MobType.valueOf(raw); } catch (Exception ex) { return null; }
    }

    public void onMobDeath(Entity mob) {
        UUID id = mob.getUniqueId();
        ArmorStand stand = healthBars.remove(id);
        if (stand != null) stand.remove();
        BossBar bb = bossBars.remove(id);
        if (bb != null) {
            bb.removeAll();
            if (plugin.getConfig().getBoolean("boss.announce", true)) {
                Bukkit.broadcastMessage(ChatColor.GOLD + "☀ " + ChatColor.YELLOW + ChatColor.BOLD +
                    "RAJA IBLIS TELAH DIKALAHKAN!" + ChatColor.GOLD + " ☀");
            }
        }
        customMobs.remove(id);
    }

    public void cleanup() {
        healthBars.values().forEach(ArmorStand::remove);
        healthBars.clear();
        bossBars.values().forEach(BossBar::removeAll);
        bossBars.clear();
        if (healthBarTask != null) healthBarTask.cancel();
    }

    public Map<UUID, MobType> getCustomMobs() { return Collections.unmodifiableMap(customMobs); }
}
