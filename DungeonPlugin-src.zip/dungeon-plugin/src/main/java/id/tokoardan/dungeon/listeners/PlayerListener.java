package id.tokoardan.dungeon.listeners;

import id.tokoardan.dungeon.DungeonPlugin;
import id.tokoardan.dungeon.mobs.MobType;
import org.bukkit.*;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

public class PlayerListener implements Listener {

    private final DungeonPlugin plugin;

    public PlayerListener(DungeonPlugin plugin) { this.plugin = plugin; }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            p.sendMessage(ChatColor.DARK_RED + "☠ " + ChatColor.RED + ChatColor.BOLD +
                "TOKOARDAN DUNGEON" + ChatColor.RESET + " " + ChatColor.DARK_RED + "☠");
            p.sendMessage(ChatColor.YELLOW + "Ketik " + ChatColor.WHITE + "/dungeon generate" +
                ChatColor.YELLOW + " untuk membuat dungeon!");
        }, 40L);
    }

    // Cegah player merusak ArmorStand health bar
    @EventHandler
    public void onArmorStandHit(EntityDamageByEntityEvent e) {
        if (e.getEntity() instanceof ArmorStand stand) {
            if (stand.getPersistentDataContainer().has(
                    new NamespacedKey("dungeon","healthbar"),
                    org.bukkit.persistence.PersistentDataType.BYTE)) {
                e.setCancelled(true);
            }
        }
    }
}
