package id.tokoardan.dungeon.dungeon;

import id.tokoardan.dungeon.mobs.MobType;
import org.bukkit.Location;

import java.util.List;

public class DungeonRoom {

    public enum RoomType {
        ENTRANCE,    // Pintu masuk
        CORRIDOR,    // Lorong
        COMBAT,      // Ruang pertarungan
        TREASURE,    // Ruang harta
        TRAP,        // Ruang jebakan
        BOSS         // Ruang boss
    }

    private final RoomType type;
    private final Location origin;    // sudut kiri bawah ruangan
    private final int width, height, depth;
    private final List<MobType> mobs;

    public DungeonRoom(RoomType type, Location origin,
                       int width, int height, int depth,
                       List<MobType> mobs) {
        this.type   = type;
        this.origin = origin.clone();
        this.width  = width;
        this.height = height;
        this.depth  = depth;
        this.mobs   = mobs;
    }

    public RoomType getType()     { return type; }
    public Location getOrigin()   { return origin.clone(); }
    public int getWidth()         { return width; }
    public int getHeight()        { return height; }
    public int getDepth()         { return depth; }
    public List<MobType> getMobs(){ return mobs; }

    /** Titik tengah ruangan */
    public Location getCenter() {
        return origin.clone().add(width / 2.0, 1, depth / 2.0);
    }
}
