package id.tokoardan.dungeon.drops;

import id.tokoardan.dungeon.mobs.MobType;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.ExperienceOrb;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.*;

public class DropManager {

    private final Random rng = new Random();
    private final id.tokoardan.dungeon.DungeonPlugin plugin;

    public DropManager(id.tokoardan.dungeon.DungeonPlugin plugin) {
        this.plugin = plugin;
    }

    // ── Drop item saat mob mati ───────────────────────────────────
    public void handleDrop(Location loc, MobType type) {
        List<ItemStack> drops = generateDrops(type);
        for (ItemStack item : drops) {
            loc.getWorld().dropItemNaturally(loc, item);
        }
        // XP
        int xp = type.xpDrop();
        if (xp > 0) {
            ExperienceOrb orb = loc.getWorld().spawn(loc, ExperienceOrb.class);
            orb.setExperience(xp);
        }
    }

    // ── Buat list drop berdasarkan tipe mob ───────────────────────
    private List<ItemStack> generateDrops(MobType type) {
        List<ItemStack> drops = new ArrayList<>();

        switch (type) {
            // ── TIER LEMAH ──────────────────────────────────────
            case GOBLIN -> {
                dropChance(drops, Material.ROTTEN_FLESH, 1, 3, 0.80);
                dropChance(drops, Material.BONE,          1, 2, 0.40);
                dropChance(drops, Material.GOLD_NUGGET,   1, 3, 0.30);
                dropChance(drops, Material.LEATHER,       1, 1, 0.20);
                rareWeapon(drops, Material.WOODEN_SWORD,  0.05, "Golok Goblin");
            }
            case GOBLIN_ARCHER -> {
                dropChance(drops, Material.ARROW,          2, 8, 0.90);
                dropChance(drops, Material.BONE,           1, 3, 0.50);
                dropChance(drops, Material.STRING,         1, 2, 0.40);
                rareWeapon(drops, Material.BOW,            0.08, "Busur Goblin");
            }
            case CAVE_BAT -> {
                dropChance(drops, Material.PHANTOM_MEMBRANE, 1, 2, 0.60);
                dropChance(drops, Material.BONE,              1, 1, 0.30);
            }

            // ── TIER MENENGAH ───────────────────────────────────
            case DUNGEON_GUARD -> {
                dropChance(drops, Material.IRON_INGOT,    1, 3, 0.50);
                dropChance(drops, Material.ROTTEN_FLESH,  2, 4, 0.70);
                dropChance(drops, Material.GOLD_INGOT,    1, 2, 0.25);
                dropChance(drops, Material.COAL,          2, 6, 0.80);
                rareArmor(drops, Material.IRON_CHESTPLATE, 0.06, "Baju Penjaga");
            }
            case DARK_MAGE -> {
                dropChance(drops, Material.SUGAR,          1, 4,  0.80);
                dropChance(drops, Material.GLOWSTONE_DUST, 1, 3,  0.60);
                dropChance(drops, Material.SPIDER_EYE,     1, 3,  0.55);
                dropChance(drops, Material.EXPERIENCE_BOTTLE, 1, 2, 0.30);
                rareWeapon(drops, Material.BLAZE_ROD,      0.12, "Tongkat Hitam");
            }
            case SKELETON_WARRIOR -> {
                dropChance(drops, Material.BONE,            2, 6, 0.90);
                dropChance(drops, Material.COAL,            1, 3, 0.60);
                dropChance(drops, Material.IRON_INGOT,      1, 2, 0.40);
                rareWeapon(drops, Material.IRON_SWORD,      0.08, "Pedang Tulang");
            }

            // ── TIER KUAT ───────────────────────────────────────
            case TROLL -> {
                dropChance(drops, Material.STONE,          4, 8, 0.90);
                dropChance(drops, Material.IRON_INGOT,     2, 4, 0.65);
                dropChance(drops, Material.RAW_IRON,       1, 3, 0.50);
                dropChance(drops, Material.EMERALD,        1, 1, 0.10);
                rareArmor(drops, Material.IRON_HELMET,     0.08, "Helm Troll");
            }
            case SHADOW_KNIGHT -> {
                dropChance(drops, Material.IRON_INGOT,     2, 5, 0.70);
                dropChance(drops, Material.DIAMOND,        1, 1, 0.05);
                dropChance(drops, Material.OBSIDIAN,       1, 2, 0.20);
                rareWeapon(drops, Material.IRON_SWORD,     0.10, "Pedang Bayangan");
                rareArmor(drops, Material.IRON_CHESTPLATE, 0.08, "Armor Bayangan");
            }
            case UNDEAD_CAPTAIN -> {
                dropChance(drops, Material.BONE,            3, 5, 0.85);
                dropChance(drops, Material.IRON_INGOT,      2, 4, 0.60);
                dropChance(drops, Material.GOLD_INGOT,      1, 2, 0.30);
                rareWeapon(drops, Material.IRON_AXE,        0.10, "Kapak Kapten");
                // Chance kepala zombie
                dropChance(drops, Material.ZOMBIE_HEAD,     1, 1, 0.03);
            }

            // ── TIER ELITE ──────────────────────────────────────
            case DEMON -> {
                dropChance(drops, Material.BLAZE_ROD,       2, 4, 0.90);
                dropChance(drops, Material.BLAZE_POWDER,    2, 6, 0.80);
                dropChance(drops, Material.MAGMA_CREAM,     1, 3, 0.50);
                dropChance(drops, Material.DIAMOND,         1, 2, 0.20);
                enchantedWeapon(drops, Material.BLAZE_ROD,  0.15, "Tombak Api Iblis",
                    Enchantment.FIRE_ASPECT, 2);
            }
            case LICH -> {
                dropChance(drops, Material.BONE,             3, 5, 0.85);
                dropChance(drops, Material.DIAMOND,          1, 3, 0.35);
                dropChance(drops, Material.NETHERITE_SCRAP,  1, 1, 0.08);
                dropChance(drops, Material.ENDER_PEARL,      1, 2, 0.40);
                enchantedWeapon(drops, Material.NETHERITE_SWORD, 0.12, "Pedang Lich",
                    Enchantment.SHARPNESS, 4);
            }
            case NIGHTMARE -> {
                dropChance(drops, Material.PHANTOM_MEMBRANE, 2, 4, 0.90);
                dropChance(drops, Material.ENDER_PEARL,      1, 2, 0.30);
                dropChance(drops, Material.DIAMOND,          1, 1, 0.12);
                enchantedArmor(drops, Material.ELYTRA,       0.03, "Sayap Mimpi Buruk");
            }

            // ── BOSS: RAJA IBLIS ────────────────────────────────
            case DEMON_KING -> {
                // Guaranteed drops
                drops.add(createNamedItem(Material.NETHER_STAR,        1, "★ Bintang Raja Iblis ★"));
                drops.add(createNamedItem(Material.DIAMOND_BLOCK,       1, "Berlian Raja Iblis"));
                drops.add(createNamedItem(Material.NETHERITE_INGOT,    4, "Logam Iblis"));
                drops.add(createNamedItem(Material.TOTEM_OF_UNDYING,   1, "Totem Raja Iblis"));

                // Chance drops
                dropChance(drops, Material.ENCHANTED_GOLDEN_APPLE, 1, 2, 0.80);
                dropChance(drops, Material.DIAMOND,                 5, 10, 1.00);
                dropChance(drops, Material.NETHERITE_SCRAP,         2, 4, 0.80);
                dropChance(drops, Material.EMERALD,                 5, 15, 1.00);

                // Senjata legenda boss
                enchantedWeapon(drops, Material.NETHERITE_SWORD, 1.0, "☠ Pedang Raja Iblis ☠",
                    Enchantment.SHARPNESS, 5);
                enchantedArmor(drops, Material.NETHERITE_CHESTPLATE, 1.0, "☠ Zirah Raja Iblis ☠");
            }
        }

        return drops;
    }

    // ── Helper: drop dengan chance ─────────────────────────────────
    private void dropChance(List<ItemStack> list, Material mat, int min, int max, double chance) {
        if (rng.nextDouble() < chance) {
            int amount = min + rng.nextInt(Math.max(1, max - min + 1));
            list.add(new ItemStack(mat, amount));
        }
    }

    // ── Helper: senjata dengan nama ────────────────────────────────
    private void rareWeapon(List<ItemStack> list, Material mat, double chance, String name) {
        if (rng.nextDouble() < chance) list.add(createNamedItem(mat, 1, name));
    }

    // ── Helper: armor dengan nama ──────────────────────────────────
    private void rareArmor(List<ItemStack> list, Material mat, double chance, String name) {
        if (rng.nextDouble() < chance) list.add(createNamedItem(mat, 1, name));
    }

    // ── Helper: item dengan enchant ────────────────────────────────
    @SuppressWarnings("deprecation")
    private void enchantedWeapon(List<ItemStack> list, Material mat, double chance,
                                  String name, Enchantment ench, int level) {
        if (rng.nextDouble() < chance) {
            ItemStack item = createNamedItem(mat, 1, name);
            item.addUnsafeEnchantment(ench, level);
            list.add(item);
        }
    }

    @SuppressWarnings("deprecation")
    private void enchantedArmor(List<ItemStack> list, Material mat, double chance, String name) {
        if (rng.nextDouble() < chance) {
            ItemStack item = createNamedItem(mat, 1, name);
            item.addUnsafeEnchantment(Enchantment.PROTECTION, 4);
            list.add(item);
        }
    }

    // ── Helper: buat item dengan nama custom ──────────────────────
    public static ItemStack createNamedItem(Material mat, int amount, String name) {
        ItemStack item = new ItemStack(mat, amount);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(ChatColor.GOLD + name);
            meta.setLore(List.of(
                ChatColor.DARK_GRAY + "Didapat dari Dungeon Bawah Tanah",
                ChatColor.DARK_GRAY + "TOKOARDAN"
            ));
            item.setItemMeta(meta);
        }
        return item;
    }
}
