package id.tokoardan.dungeon.commands;

import id.tokoardan.dungeon.DungeonPlugin;
import id.tokoardan.dungeon.dungeon.DungeonGenerator;
import id.tokoardan.dungeon.mobs.MobType;
import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

import java.util.Arrays;
import java.util.List;

public class DungeonCommand implements CommandExecutor, TabCompleter {

    private final DungeonPlugin plugin;
    private final DungeonGenerator generator;

    public DungeonCommand(DungeonPlugin plugin) {
        this.plugin    = plugin;
        this.generator = new DungeonGenerator(plugin);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }

        switch (args[0].toLowerCase()) {

            case "generate", "gen", "create" -> {
                if (!sender.hasPermission("dungeon.admin")) {
                    sender.sendMessage(ChatColor.RED + "Kamu tidak punya izin!");
                    return true;
                }
                if (!(sender instanceof Player p)) {
                    sender.sendMessage(ChatColor.RED + "Hanya player!");
                    return true;
                }
                generator.generate(p.getLocation(), p);
            }

            case "tp", "teleport" -> {
                if (!(sender instanceof Player p)) {
                    sender.sendMessage(ChatColor.RED + "Hanya player!");
                    return true;
                }
                // Teleport ke y=-30 di bawah posisi saat ini
                int depth = plugin.getConfig().getInt("dungeon.depth", -30);
                Location dest = p.getLocation().clone();
                dest.setY(depth + 2);
                p.teleport(dest);
                p.sendMessage(ChatColor.GREEN + "✔ Teleport ke dungeon! Y=" + depth);
                p.playSound(dest, Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 1f);
            }

            case "spawnmob" -> {
                if (!sender.hasPermission("dungeon.admin")) {
                    sender.sendMessage(ChatColor.RED + "Kamu tidak punya izin!"); return true;
                }
                if (!(sender instanceof Player p)) {
                    sender.sendMessage(ChatColor.RED + "Hanya player!"); return true;
                }
                if (args.length < 2) {
                    sender.sendMessage(ChatColor.RED + "Usage: /dungeon spawnmob <type>");
                    sender.sendMessage(ChatColor.YELLOW + "Types: " +
                        String.join(", ", Arrays.stream(MobType.values()).map(Enum::name).toList()));
                    return true;
                }
                try {
                    MobType type = MobType.valueOf(args[1].toUpperCase());
                    plugin.getMobManager().spawnMob(p.getLocation(), type);
                    p.sendMessage(ChatColor.GREEN + "✔ Spawned " + type.coloredName());
                } catch (IllegalArgumentException ex) {
                    sender.sendMessage(ChatColor.RED + "Tipe mob tidak dikenali: " + args[1]);
                }
            }

            case "info" -> {
                sender.sendMessage(ChatColor.GOLD + "═══ DungeonPlugin Info ═══");
                sender.sendMessage(ChatColor.YELLOW + "Mob aktif: " +
                    ChatColor.WHITE + plugin.getMobManager().getCustomMobs().size());
                sender.sendMessage(ChatColor.YELLOW + "Version: " + ChatColor.WHITE + "1.0.0");
                sender.sendMessage(ChatColor.YELLOW + "Author: " + ChatColor.WHITE + "TOKOARDAN");
            }

            case "reload" -> {
                if (!sender.hasPermission("dungeon.admin")) {
                    sender.sendMessage(ChatColor.RED + "Kamu tidak punya izin!"); return true;
                }
                plugin.reloadConfig();
                sender.sendMessage(ChatColor.GREEN + "✔ Config di-reload!");
            }

            default -> sendHelp(sender);
        }

        return true;
    }

    private void sendHelp(CommandSender s) {
        s.sendMessage(ChatColor.DARK_RED + "☠ " + ChatColor.GOLD + ChatColor.BOLD +
            "DUNGEON COMMANDS" + ChatColor.DARK_RED + " ☠");
        s.sendMessage(ChatColor.YELLOW + "/dungeon generate" + ChatColor.WHITE +
            " — Generate dungeon di lokasi kamu");
        s.sendMessage(ChatColor.YELLOW + "/dungeon tp" + ChatColor.WHITE +
            " — Teleport ke kedalaman dungeon");
        s.sendMessage(ChatColor.YELLOW + "/dungeon spawnmob <type>" + ChatColor.WHITE +
            " — Spawn mob custom");
        s.sendMessage(ChatColor.YELLOW + "/dungeon info" + ChatColor.WHITE +
            " — Info plugin");
        s.sendMessage(ChatColor.YELLOW + "/dungeon reload" + ChatColor.WHITE +
            " — Reload config");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length == 1) {
            return List.of("generate","tp","spawnmob","info","reload");
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("spawnmob")) {
            return Arrays.stream(MobType.values()).map(Enum::name).toList();
        }
        return List.of();
    }
}
