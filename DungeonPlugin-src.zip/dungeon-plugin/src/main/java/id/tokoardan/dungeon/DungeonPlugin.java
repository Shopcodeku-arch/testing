package id.tokoardan.dungeon;

import id.tokoardan.dungeon.commands.DungeonCommand;
import id.tokoardan.dungeon.drops.DropManager;
import id.tokoardan.dungeon.listeners.MobListener;
import id.tokoardan.dungeon.listeners.PlayerListener;
import id.tokoardan.dungeon.mobs.MobManager;
import org.bukkit.plugin.java.JavaPlugin;

public class DungeonPlugin extends JavaPlugin {

    private static DungeonPlugin instance;
    private MobManager mobManager;
    private DropManager dropManager;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        this.mobManager  = new MobManager(this);
        this.dropManager = new DropManager(this);

        // Register listeners
        getServer().getPluginManager().registerEvents(new MobListener(this), this);
        getServer().getPluginManager().registerEvents(new PlayerListener(this), this);

        // Register commands
        DungeonCommand cmd = new DungeonCommand(this);
        getCommand("dungeon").setExecutor(cmd);
        getCommand("dungeon").setTabCompleter(cmd);

        // Start health bar updater
        mobManager.startHealthBarTask();

        getLogger().info("╔══════════════════════════════╗");
        getLogger().info("║  DungeonPlugin aktif!        ║");
        getLogger().info("║  /dungeon generate           ║");
        getLogger().info("╚══════════════════════════════╝");
    }

    @Override
    public void onDisable() {
        if (mobManager != null) mobManager.cleanup();
        getLogger().info("[DungeonPlugin] Plugin dinonaktifkan.");
    }

    public static DungeonPlugin getInstance() { return instance; }
    public MobManager getMobManager()          { return mobManager; }
    public DropManager getDropManager()        { return dropManager; }
}
