package id.tokoardan.dungeon.mobs;

import org.bukkit.ChatColor;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.EntityType;

/**
 * Semua tipe mob dungeon dari lemah hingga boss
 */
public enum MobType {

    // ── TIER 1: Musuh Lemah ──────────────────────────────────────
    GOBLIN(
        "Goblin",           ChatColor.GREEN,
        EntityType.ZOMBIE,
        12, 3,              // hp, attack
        1, 0.3,             // armor, speed boost
        Tier.WEAK,          false
    ),
    GOBLIN_ARCHER(
        "Goblin Pemanah",   ChatColor.GREEN,
        EntityType.SKELETON,
        10, 4,
        0, 0.25,
        Tier.WEAK,          false
    ),
    CAVE_BAT(
        "Kelelawar Gua",    ChatColor.DARK_GRAY,
        EntityType.PHANTOM,
        8, 2,
        0, 0.4,
        Tier.WEAK,          false
    ),

    // ── TIER 2: Musuh Menengah ───────────────────────────────────
    DUNGEON_GUARD(
        "Penjaga Penjara",  ChatColor.YELLOW,
        EntityType.ZOMBIE_VILLAGER,
        30, 6,
        4, 0.22,
        Tier.MEDIUM,        false
    ),
    DARK_MAGE(
        "Penyihir Gelap",   ChatColor.DARK_PURPLE,
        EntityType.WITCH,
        28, 8,
        2, 0.26,
        Tier.MEDIUM,        false
    ),
    SKELETON_WARRIOR(
        "Ksatria Tulang",   ChatColor.WHITE,
        EntityType.WITHER_SKELETON,
        35, 7,
        5, 0.24,
        Tier.MEDIUM,        false
    ),

    // ── TIER 3: Musuh Kuat ───────────────────────────────────────
    TROLL(
        "Troll Batu",       ChatColor.GRAY,
        EntityType.HOGLIN,
        80, 12,
        6, 0.18,
        Tier.STRONG,        false
    ),
    SHADOW_KNIGHT(
        "Ksatria Bayangan", ChatColor.DARK_BLUE,
        EntityType.ZOMBIE,
        60, 10,
        8, 0.22,
        Tier.STRONG,        false
    ),
    UNDEAD_CAPTAIN(
        "Kapten Arwah",     ChatColor.RED,
        EntityType.SKELETON,
        50, 9,
        4, 0.28,
        Tier.STRONG,        false
    ),

    // ── TIER 4: Elite ────────────────────────────────────────────
    DEMON(
        "Iblis Api",        ChatColor.GOLD,
        EntityType.BLAZE,
        100, 15,
        8, 0.3,
        Tier.ELITE,         false
    ),
    LICH(
        "Lich",             ChatColor.LIGHT_PURPLE,
        EntityType.WITHER_SKELETON,
        120, 18,
        10, 0.26,
        Tier.ELITE,         false
    ),
    NIGHTMARE(
        "Mimpi Buruk",      ChatColor.DARK_RED,
        EntityType.PHANTOM,
        90, 14,
        6, 0.38,
        Tier.ELITE,         false
    ),

    // ── BOSS ─────────────────────────────────────────────────────
    DEMON_KING(
        "☠ RAJA IBLIS ☠",  ChatColor.DARK_RED,
        EntityType.WITHER,
        600, 35,
        20, 0.0,            // wither punya movement sendiri
        Tier.BOSS,          true
    );

    // ── Fields ───────────────────────────────────────────────────
    public final String displayName;
    public final ChatColor color;
    public final EntityType entityType;
    public final double maxHealth;
    public final double attackDamage;
    public final double armorPoints;
    public final double speedBoost;     // tambahan kecepatan dari default
    public final Tier tier;
    public final boolean isBoss;

    MobType(String displayName, ChatColor color, EntityType entityType,
            double maxHealth, double attackDamage,
            double armorPoints, double speedBoost,
            Tier tier, boolean isBoss) {
        this.displayName  = displayName;
        this.color        = color;
        this.entityType   = entityType;
        this.maxHealth    = maxHealth;
        this.attackDamage = attackDamage;
        this.armorPoints  = armorPoints;
        this.speedBoost   = speedBoost;
        this.tier         = tier;
        this.isBoss       = isBoss;
    }

    public enum Tier { WEAK, MEDIUM, STRONG, ELITE, BOSS }

    /** Nama tampilan berwarna lengkap */
    public String coloredName() {
        return color + (isBoss ? ChatColor.BOLD.toString() : "") + displayName;
    }

    /** XP yang didapat saat membunuh */
    public int xpDrop() {
        return switch (tier) {
            case WEAK   -> 5;
            case MEDIUM -> 15;
            case STRONG -> 30;
            case ELITE  -> 60;
            case BOSS   -> 300;
        };
    }
}
