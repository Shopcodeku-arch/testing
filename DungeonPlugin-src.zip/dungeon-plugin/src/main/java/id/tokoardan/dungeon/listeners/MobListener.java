package id.tokoardan.dungeon.listeners;

import id.tokoardan.dungeon.DungeonPlugin;
import id.tokoardan.dungeon.mobs.MobType;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.*;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class MobListener implements Listener {

    private final DungeonPlugin plugin;

    public MobListener(DungeonPlugin plugin) { this.plugin = plugin; }

    // ── Mob mati → drop item + notif ─────────────────────────────
    @EventHandler(priority = EventPriority.HIGH)
    public void onMobDeath(EntityDeathEvent e) {
        Entity entity = e.getEntity();
        if (!plugin.getMobManager().isDungeonMob(entity)) return;

        MobType type = plugin.getMobManager().getMobType(entity);
        if (type == null) return;

        // Hapus drop vanilla
        e.getDrops().clear();
        e.setDroppedExp(0);

        // Drop sistem custom
        plugin.getDropManager().handleDrop(entity.getLocation(), type);

        // Cleanup healthbar
        plugin.getMobManager().onMobDeath(entity);

        // Particle kematian
        entity.getWorld().spawnParticle(Particle.SOUL, entity.getLocation(), 20, 0.5, 1, 0.5, 0.05);
        entity.getWorld().playSound(entity.getLocation(), Sound.ENTITY_WITHER_DEATH, 0.5f, 1.2f);

        // Notif kill ke pembunuh
        if (e.getEntity().getKiller() != null) {
            Player killer = e.getEntity().getKiller();
            killer.sendMessage(
                ChatColor.GOLD + "✔ Kamu membunuh " +
                type.coloredName() + ChatColor.GOLD + "!"
            );
            killer.sendMessage(
                ChatColor.YELLOW + "+" + type.xpDrop() + " XP"
            );
        }
    }

    // ── Cegah mob dungeon despawn ─────────────────────────────────
    @EventHandler
    public void onChunkUnload(org.bukkit.event.world.ChunkUnloadEvent e) {
        // Mob dungeon sudah di-persist via PDC, aman
    }

    // ── Custom behavior saat mob serang player ─────────────────────
    @EventHandler
    public void onEntityDamageByEntity(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof LivingEntity attacker)) return;
        if (!plugin.getMobManager().isDungeonMob(attacker)) return;
        if (!(e.getEntity() instanceof Player player)) return;

        MobType type = plugin.getMobManager().getMobType(attacker);
        if (type == null) return;

        // Efek khusus tiap tipe mob
        switch (type) {
            case DARK_MAGE -> {
                // Slowness + blindness
                player.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, 60, 1));
                if (Math.random() < 0.3) player.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 40, 0));
            }
            case SHADOW_KNIGHT -> {
                // Weakness
                if (Math.random() < 0.4) player.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 80, 0));
            }
            case TROLL -> {
                // Knockback ekstra
                player.setVelocity(player.getLocation().getDirection().multiply(-1.5).setY(0.5));
            }
            case LICH -> {
                // Wither effect
                if (Math.random() < 0.5) player.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, 60, 1));
            }
            case NIGHTMARE -> {
                // Levitation sebentar
                if (Math.random() < 0.3) player.addPotionEffect(new PotionEffect(PotionEffectType.LEVITATION, 30, 0));
            }
            case DEMON -> {
                // Fire damage ekstra
                player.setFireTicks(80);
            }
            case DEMON_KING -> {
                // Semua efek buruk
                player.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, 100, 1));
                player.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, 60, 2));
                player.setFireTicks(100);
                if (Math.random() < 0.3) {
                    player.sendMessage(ChatColor.DARK_RED + "☠ " + ChatColor.RED +
                        "Raja Iblis: \"Kamu tidak bisa mengalahkanku!\"");
                }
            }
            default -> {}
        }
    }

    // ── Mob spawn natural di area dungeon: replace dengan custom ─
    @EventHandler
    public void onCreatureSpawn(CreatureSpawnEvent e) {
        // Hanya handle natural spawn — biarkan dungeon spawn lewat MobManager
        if (e.getSpawnReason() == CreatureSpawnEvent.SpawnReason.PLUGIN) return;

        // Check apakah lokasi spawn ada di area dungeon (y < -20)
        if (e.getLocation().getY() < -20) {
            // Biarkan spawn normal di bawah, tapi kita bisa override jika perlu
        }
    }

    // ── Target selector: mob dungeon hanya kejar player ──────────
    @EventHandler
    public void onEntityTarget(EntityTargetEvent e) {
        if (!plugin.getMobManager().isDungeonMob(e.getEntity())) return;
        // Pastikan hanya target player
        if (e.getTarget() != null && !(e.getTarget() instanceof Player)) {
            e.setCancelled(true);
        }
    }

    // ── Cegah mob dungeon terbakar siang ─────────────────────────
    @EventHandler
    public void onEntityCombust(EntityCombustEvent e) {
        if (plugin.getMobManager().isDungeonMob(e.getEntity())) {
            e.setCancelled(true);
        }
    }
}
